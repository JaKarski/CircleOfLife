from Grafika.Manager import *
from Grafika.Wymiary import *

Wymiary = Wymiary()
Manager(Wymiary.x, Wymiary.y)
